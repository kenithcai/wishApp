//
//  AudioPlayViewController.h
//  zFM
//
//  Created by zykhbl on 15-9-25.
//  Copyright (c) 2015年 zykhbl. All rights reserved.
//

#import "PulleyViewController.h"

@interface AudioPlayViewController : PulleyViewController

@property (nonatomic, strong) UIViewController *playVC;
@property (nonatomic, strong) UIViewController *ipodEQVC;
@property (nonatomic, strong) UIViewController *customEQVC;

@end
