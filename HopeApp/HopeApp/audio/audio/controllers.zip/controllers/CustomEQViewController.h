//
//  CustomEQViewController.h
//  zFM
//
//  Created by zykhbl on 15-9-25.
//  Copyright (c) 2015年 zykhbl. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomEQViewController : UIViewController

@property (nonatomic, strong) UISegmentedControl *segmentedControl;
@property (nonatomic, strong) NSMutableArray *sliderArray;
@property (nonatomic, strong) NSMutableArray *labelArray;

@end
